<footer class="footer">
  <div class="container">
    <nav class="float-left">
      <ul>
        <li>
          <a href="http://dinospizza.cl/">
            Página Web
          </a>
        </li>
      </ul>
    </nav>
    <div class="copyright float-right">
      &copy;
      <script>
        document.write(new Date().getFullYear())
      </script>, 
      <a href="http://magor.cl/" target="_blank">Desarrollado por Magor Spa.</a>
    </div>
  </div>
</footer>