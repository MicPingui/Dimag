@extends('layouts.app')

@section('body-class', 'signup-page')

@section('content')



@endsection