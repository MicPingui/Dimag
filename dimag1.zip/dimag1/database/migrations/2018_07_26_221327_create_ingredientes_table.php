<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateIngredientesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ingredientes', function (Blueprint $table) {
            $table->increments('idIngrediente')->unsigned();
            $table->string('nombreIngrediente');
            $table->integer('idUnidadMedida')->index()->unsigned();
            $table->foreign('idUnidadMedida')->references('idUnidadMedida')->on('unidad_medidas');
            $table->boolean('estadoIngrediente')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ingredientes');
    }
}
