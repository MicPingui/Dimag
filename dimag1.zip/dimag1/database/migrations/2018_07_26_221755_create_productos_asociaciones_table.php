<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductosAsociacionesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('productos_asociaciones', function (Blueprint $table) {
            $table->increments('idAsociacionProducto')->unsigned();
            $table->integer('idProducto')->unsigned();
            $table->foreign('idProducto')->references('idProducto')->on('productos');
            $table->integer('idAsociacion')->index()->unsigned();
            $table->foreign('idAsociacion')->references('idAsociacion')->on('asociaciones');
            $table->integer('precioUnitarioProducto')->unsigned();
            $table->integer('cantidadProducto')->unsigned();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('productos_asociaciones');
    }
}
