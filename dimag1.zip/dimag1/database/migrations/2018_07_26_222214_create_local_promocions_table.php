<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLocalPromocionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('local_promocions', function (Blueprint $table) {
            $table->increments('idLocalPromocion')->unsigned();
            $table->integer('idLocal')->index()->unsigned();
            $table->foreign('idLocal')->references('idLocal')->on('locals');
            $table->integer('idPromocion')->unsigned();
            $table->foreign('idPromocion')->references('idPromocion')->on('promocions');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('local_promocions');
    }
}
