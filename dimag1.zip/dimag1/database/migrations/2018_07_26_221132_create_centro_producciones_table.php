<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCentroProduccionesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('centro_producciones', function (Blueprint $table) {
            $table->increments('idCentroProduccion')->unsigned();
            $table->string('nombreCentroProduccion');
            $table->string('descripcionCentroProduccion');
            $table->boolean('estadoCentroProduccion');
            $table->integer('idLocal')->unsigned();
            $table->foreign('idLocal')->references('idLocal')->on('locals');
            $table->integer('idSector')->nullable()->unsigned();
            $table->foreign('idSector')->references('idSector')->on('sectores');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('centro_producciones');
    }
}
