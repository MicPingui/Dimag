<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLocalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('locals', function (Blueprint $table) {
            $table->increments('idLocal')->unsigned();
            $table->string('nombreLocal');
            $table->string('direccionLocal');
            $table->integer('idComuna')->unsigned();
            $table->foreign('idComuna')->references('idComuna')->on('comunas');
            $table->integer('idCiudad')->unsigned();
            $table->foreign('idCiudad')->references('idCiudad')->on('ciudades');
            $table->string('personaContactoLocal')->nullable();
            $table->integer('estadoLocal');
            $table->string('horarioAtencionLocal')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('locals');
    }
}
