<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductosPromocionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('productos_promocions', function (Blueprint $table) {
            $table->increments('idProductoPromocion')->unsigned();
            $table->integer('idProducto')->index()->unsigned();
            $table->foreign('idProducto')->references('idProducto')->on('productos');
            $table->integer('idPromocion')->index()->unsigned();
            $table->foreign('idPromocion')->references('idPromocion')->on('promocions');
            $table->integer('precioUnitarioProducto')->unsigned();
            $table->integer('cantidadProducto')->unsigned();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('productos_promocions');
    }
}
