<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePagosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pagos', function (Blueprint $table) {
            $table->increments('idPago')->unsigned();
            $table->integer('idLocal')->index()->unsigned();
            $table->foreign('idLocal')->references('idLocal')->on('locals');
            $table->integer('idSector')->index()->unsigned();
            $table->foreign('idSector')->references('idSector')->on('sectores');
            $table->integer('idMesa')->index()->unsigned();
            $table->foreign('idMesa')->references('idMesa')->on('mesas');
            $table->integer('idCuenta')->index()->unsigned();
            $table->foreign('idCuenta')->references('idCuenta')->on('cuentas');
            $table->integer('idTipoPago')->index()->unsigned();
            $table->foreign('idTipoPago')->references('idTipoPago')->on('tipo_pagos');
            $table->string('observacionTipoPago')->nullable();
            $table->integer('montoPago');
            $table->integer('idBanco')->nullable()->index()->unsigned();
            $table->foreign('idBanco')->references('idBanco')->on('bancos');
            $table->integer('descuentoPago')->nullable();
            $table->integer('recargoPago')->nullable();
            $table->integer('montoPropina')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pagos');
    }
}
