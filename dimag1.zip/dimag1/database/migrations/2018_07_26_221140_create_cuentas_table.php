<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCuentasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cuentas', function (Blueprint $table) {
            $table->increments('idCuenta')->unsigned();
            $table->integer('idLocal')->index()->unsigned();
            $table->foreign('idLocal')->references('idLocal')->on('locals');
            $table->integer('idSector')->index()->unsigned();
            $table->foreign('idSector')->references('idSector')->on('sectores');
            $table->integer('idMesa')->index()->unsigned();
            $table->foreign('idMesa')->references('idMesa')->on('mesas');
            $table->integer('idCliente')->index()->unsigned();
            $table->foreign('idCliente')->references('idCliente')->on('clientes');
            $table->integer('idPedido')->index()->unsigned();
            $table->foreign('idPedido')->references('idPedido')->on('pedidos');
            $table->integer('idCaja')->index()->unsigned();
            $table->foreign('idCaja')->references('idCaja')->on('cajas');
            $table->boolean('propina');
            $table->integer('montoPropina')->unsigned();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cuentas');
    }
}
