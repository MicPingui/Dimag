<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateClientesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clientes', function (Blueprint $table) {
            $table->increments('idCliente')->unsigned();
            $table->string('nombreCliente');
            $table->string('direccionCliente');
            $table->string('telefonoCliente');
            $table->string('correoElectronicoCliente')->nullable();
            $table->integer('generoCliente')->unique()->unsigned();
            $table->foreign('generoCliente')->references('idGenero')->on('generos');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clientes');
    }
}
