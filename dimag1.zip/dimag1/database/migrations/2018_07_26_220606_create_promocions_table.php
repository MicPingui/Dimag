<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePromocionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('promocions', function (Blueprint $table) {
            $table->increments('idPromocion')->unsigned();
            $table->string('nombrePromocion');
            $table->dateTime('fechaInicioPromocion');
            $table->dateTime('fechaTerminoPromocion');
            $table->integer('estadoPromocion');
            $table->binary('imagenPromocion')->nullable();
            $table->string('condicionPromocion')->nullable();
            $table->mediumText('observacionPromocion')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('promocions');
    }
}
