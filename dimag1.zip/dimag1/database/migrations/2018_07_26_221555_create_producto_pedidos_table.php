<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductoPedidosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('producto_pedidos', function (Blueprint $table) {
            $table->bigIncrements('idProductoPedido')->unsigned();
            $table->integer('idProducto')->index()->unsigned();
            $table->foreign('idProducto')->references('idProducto')->on('productos');
            $table->integer('idPedido')->index()->unsigned();
            $table->foreign('idPedido')->references('idPedido')->on('pedidos');
            $table->integer('idRecetaCliente')->nullable()->index()->unsigned();
            $table->foreign('idRecetaCliente')->references('idRecetaCliente')->on('receta_clientes');
            $table->string('observacionesProductoPedido')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('producto_pedidos');
    }
}
