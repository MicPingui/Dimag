<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePedidosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pedidos', function (Blueprint $table) {
            $table->increments('idPedido')->unsigned();
            $table->integer('tipoPedido')->index()->unsigned();
            $table->foreign('tipoPedido')->references('idTipoPedido')->on('tipo_pedidos');
            $table->integer('idLocal')->index()->unsigned();
            $table->foreign('idLocal')->references('idLocal')->on('locals');
            $table->integer('idSector')->index()->unsigned();
            $table->foreign('idSector')->references('idSector')->on('sectores');
            $table->integer('idMesa')->index()->unsigned();
            $table->foreign('idMesa')->references('idMesa')->on('mesas');
            $table->integer('idCliente')->index()->unsigned();
            $table->foreign('idCliente')->references('idCliente')->on('clientes');
            $table->integer('idUsuario')->index()->unsigned();
            $table->foreign('idUsuario')->references('id')->on('users');
            $table->string('observacionesPedido');
            $table->integer('idCentroProduccion')->index()->unsigned();
            $table->foreign('idCentroProduccion')->references('idCentroProduccion')->on('centro_producciones');
            $table->integer('idAsociacion')->index()->unsigned();
            $table->foreign('idAsociacion')->references('idAsociacion')->on('asociaciones');
            $table->integer('idEstadoPedido')->index()->unsigned();
            $table->foreign('idEstadoPedido')->references('idEstadoPedido')->on('estado_pedidos');
            $table->integer('idEntregaDomicilio')->index()->unsigned();
            $table->foreign('idEntregaDomicilio')->references('idEntregaDomicilio')->on('entrega_domicilios');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pedidos');
    }
}
