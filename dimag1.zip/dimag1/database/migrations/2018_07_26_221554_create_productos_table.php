<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('productos', function (Blueprint $table) {
            $table->increments('idProducto')->unsigned();
            $table->string('nombreProducto');
            $table->integer('idFamilia')->index()->unsigned();
            $table->foreign('idFamilia')->references('idFamilia')->on('familias');
            $table->integer('idRecetaNegocio')->index()->unsigned();
            $table->foreign('idRecetaNegocio')->references('idRecetaNegocio')->on('receta_negocios');
            $table->integer('tiempoPreparacionProducto')->unsigned();
            $table->boolean('estadoProducto')->default(true);
            $table->binary('imagenProducto')->nullable();
            $table->string('observacionesProducto')->nullable();
            $table->integer('idTamano')->nullable()->index()->unsigned();
            $table->foreign('idTamano')->references('idTamano')->on('tamanos');
            $table->integer('precioComercialProducto')->unsigned();
            $table->integer('precioCostoProducto')->nullable()->unsigned();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('productos');
    }
}
