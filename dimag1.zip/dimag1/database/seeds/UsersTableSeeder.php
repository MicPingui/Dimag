<?php

use Illuminate\Database\Seeder;
use App\User;
use App\PerfilSeguridad;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        PerfilSeguridad::create([
            'nombrePerfilSeguridad'=>'Administrador',
        ]);

        User::create([

        	'name'=>'Administrador',
        	'email'=>'admin',
        	'password'=>bcrypt('admin'),
        	'idPerfilSeguridad'=>1,
        ]);
    }
}
