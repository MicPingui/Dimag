<!doctype html>
<html lang="es">
    <head>
        <meta charset="utf-8" />
        <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('img/vaca.png')); ?>">
        <link rel="icon" type="image/png" href="<?php echo e(asset('img/vaca.png')); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>Dinos Pizza</title>
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
        <!-- CSS Files -->
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
        <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('css/material-kit.css')); ?>" rel="stylesheet"/>
        <?php echo $__env->yieldContent('style'); ?>
        <style type="text/css">
            footer {
                position: absolute;
                bottom: 0;
                width: 100%;
                height: 70px;  
            }

            img{
                width: 100%;
                height: auto;   
            }

        </style>

    </head>

    <body class = "<?php echo $__env->yieldContent('body-class'); ?>">
       <nav class="navbar navbar-expand-lg bg-success">
    <div class="container">
        <div class="navbar-translate">
            <a class="navbar-brand" href="/presentation.html"><img src="<?php echo e(asset('/img/logoDinos.png')); ?>"></a>
            
            <button class="navbar-toggler" type="button" data-toggle="collapse" aria-expanded="false" aria-label="Toggle navigation" data-target="#colapsada">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon"></span>
            <span class="navbar-toggler-icon"></span>
            <span class="navbar-toggler-icon"></span>
            </button>
        </div>

        <div class="collapse navbar-collapse" id="colapsada">
            <ul class="navbar-nav ml-auto">
                <?php if(auth()->guard()->guest()): ?>
                <?php else: ?>
                <li class="nav-item active">
                    <span class="btn btn-round" style="color: white; width: 100%; font-size:70%;"><i class="material-icons">person</i> Bienvenido/a: <?php echo e(Auth::user()->name); ?></span>
                </li>

                 
               <li class="button-container nav-item iframe-extern">
                <form method="post" action="<?php echo e(url('logout')); ?>" class="form-inline ml-auto">
                    <?php echo e(csrf_field()); ?>

                    <button type="submit" class="btn btn-danger btn-round btn-block"><i class="material-icons">power_settings_new</i> Cerrar Sesión </button>
                </form>
               </li>
                <?php endif; ?>
            </ul>
             
        </div>
    </div>
</nav>

    <!--<div class="card">
        <div class="card-body">
            <span class="btn btn-link" style="color: black;"><i class="material-icons">person</i> Bienvenido/a: <?php echo e(Auth::user()->name); ?></span>
        </div>
    </div> -->

       <?php if(session()->has('flash')): ?>
        <div class="alert alert-info">
            <?php echo e(session('flash')); ?>

        </div>
       <?php endif; ?>
        <div class="wrapper">
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </body>
    <?php echo $__env->yieldContent('script'); ?>

    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('js/core/jquery.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/core/popper.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/core/bootstrap-material-design.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/plugins/moment.min.js')); ?>" type="text/javascript"></script>

    <!-- No Core JS Files -->
    <script src="<?php echo e(asset('js/material-kit.min.js')); ?>" type="text/javascript"></script>
</html>

<!-- 
#9C27b0
rgb(156, 39, 176)
-->