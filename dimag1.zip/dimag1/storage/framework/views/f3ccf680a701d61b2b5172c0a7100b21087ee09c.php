<?php $__env->startSection('body-class', 'signup-page'); ?>

<?php $__env->startSection('content'); ?>
	<div class="page-header header-filter" style="background-image: url('<?php echo e(asset('img/foto7.jpg')); ?>'); background-position: center;">
    <?php if(session()->has('flash')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('flash')); ?>

        </div>
       <?php endif; ?>
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 ml-auto mr-auto">
          <div class="card card-login">
            <form class="form" method="post" action="<?php echo e(url('/login')); ?>">
            	<?php echo e(csrf_field()); ?>

              <div class="card-header card-header-success  text-center">
                <h4 class="card-title"><img src="<?php echo e(asset('/img/LogoIntermedio.png')); ?>"></h4>
                
              </div>
              
              <div class="card-body">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">face</i>
                    </span>
                  </div>
                  <input type="text" id="email" class="form-control" value="<?php echo e(old('email')); ?>" name="email" placeholder="Usuario">
                </div>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons">lock_outline</i>
                    </span>
                  </div>
                  <input type="password" class="form-control" name="password" placeholder="Contraseña">
                </div>
              </div>
              <div class="text-center">
                <button type="submit" class="btn btn-success  btn-wd btn-lg">Ingresar</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>