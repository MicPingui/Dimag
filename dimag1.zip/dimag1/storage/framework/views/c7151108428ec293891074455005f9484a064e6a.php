<!doctype html>
<html lang="es">
    <head>
        <meta charset="utf-8" />
        <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('img/vaca.png')); ?>">
        <link rel="icon" type="image/png" href="<?php echo e(asset('img/vaca.png')); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>Dinos Pizza</title>
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
        <!-- CSS Files -->
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
        <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('css/material-kit.css')); ?>" rel="stylesheet"/>
        <?php echo $__env->yieldContent('style'); ?>
        <style type="text/css">
            footer {
                position: absolute;
                bottom: 0;
                width: 100%;
                height: 70px;  
            }

        </style>

    </head>

    <body class = "<?php echo $__env->yieldContent('body-class'); ?>">
        <nav class="navbar navbar-transparent navbar-color-on-scroll fixed-top navbar-expand-lg" color-on-scroll="100" id="sectionsNav">
            <div class="container">
               <?php if(session()->has('flash')): ?>
                <div class="alert alert-info">
                    <?php echo e(session('flash')); ?>

                </div>
               <?php endif; ?>
                <div class="navbar-translate">
                    <a class="navbar-brand" href="#">
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="navbar-toggler-icon"></span>
                        <span class="navbar-toggler-icon"></span>
                        <span class="navbar-toggler-icon"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="navbar-nav ml-auto">
                       <?php if(auth()->guard()->guest()): ?>
                    
                        <?php else: ?>
                       <li class="nav-item">
                           <form method="post" action="<?php echo e(url('logout')); ?>">
                               <?php echo e(csrf_field()); ?>

                               <button type="submit" class="btn btn-danger">Cerrar Sesión</button>
                           </form>
                       </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="wrapper">
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </body>
    <?php echo $__env->yieldContent('script'); ?>

    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('js/core/jquery.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/core/popper.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/core/bootstrap-material-design.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/plugins/moment.min.js')); ?>" type="text/javascript"></script>

    <!-- No Core JS Files -->
    <script src="<?php echo e(asset('js/material-kit.min.js')); ?>" type="text/javascript"></script>
</html>

<!-- 
#9C27b0
rgb(156, 39, 176)
-->