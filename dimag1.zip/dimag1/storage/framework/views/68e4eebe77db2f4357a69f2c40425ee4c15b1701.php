<?php $__env->startSection('body-class', 'signup-page'); ?>

<?php $__env->startSection('content'); ?>

<nav class="navbar navbar-expand-lg bg-dark">
  
</nav>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>