<?php $__env->startSection('body-class', 'signup-page'); ?>
<?php $__env->startSection('style'); ?>
	<style type="text/css">
		.form-actions  {
			margin-left: auto;
			margin-right: auto;	
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-1"></div>
		<?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-5">
				<div class="card">
					<div class="card-header">
						<h3 align="center"><?php echo e($local->nombreLocal); ?></h3>
					</div>
					<div class="card-body">
						<p style="color: black;">Ubicacion: <?php echo e($local->direccionLocal); ?></p>
						<p style="color: black;">Horario: <?php echo e($local->horarioAtencionLocal); ?></p>
						<div class="row">
							<div class="form-actions">
								<button type="button" data-toggle="modal" data-target="#modalSector.<?php echo e($local->idLocal); ?>" class="btn btn-success">Seleccionar</button>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Modal -->
			<div class="modal fade" id="modalSector.<?php echo e($local->idLocal); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog" role="document">
			    <div class="modal-content">
			      <div class="modal-header">
			        <h5 class="modal-title" id="exampleModalLabel">Seleccione el Sector</h5>
			        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			          <span aria-hidden="true">&times;</span>
			        </button>
			      </div>
			      <div class="modal-body">
			        <?php $__currentLoopData = $sectores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        	<?php if($local->idLocal == $sector->idLocal): ?>
				        	<a href="#" class="btn btn-success">
				        	<?php echo e($sector->nombreSector); ?>		
				        		
			        		</a>
			        	<?php else: ?>
			        		Este local no tiene sectores asociados.
				        <?php endif; ?>
			        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			      </div>
			      <div class="modal-footer">
			        <button type="button" class="btn btn-danger" data-dismiss="modal">Salir</button>
			        <button type="button" class="btn btn-success">Seleccionar</button>
			      </div>
			    </div>
			  </div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<div class="col-md-1"></div>
	</div>

	
<?php $__env->stopSection(); ?>


<!-- Force next columns to break to new line -->
  <!-- <div class="w-100"></div> -->
<?php echo $__env->make('layouts.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>