<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

/**
 * @property int $id
 * @property string $name
 * @property string $username
 * @property string $password
 * @property int $idPerfilSeguridad
 * @property string $remember_token
 * @property string $created_at
 * @property string $updated_at
 * @property SeguridadPerfile $seguridadPerfile
 * @property Pedido $pedido
 */
class User extends Authenticatable
{
    /**
     * @var array
     */
    protected $fillable = ['name', 'email', 'password', 'idPerfilSeguridad', 'remember_token', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function seguridadPerfile()
    {
        return $this->belongsTo('App\SeguridadPerfile', 'idPerfilSeguridad', 'idPerfilSeguridad');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function pedido()
    {
        return $this->hasOne('App\Pedido', 'idUsuario');
    }
}
