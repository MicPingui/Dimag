<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $idLocal
 * @property string $nombreLocal
 * @property string $direccionLocal
 * @property int $idComuna
 * @property int $idCiudad
 * @property string $personaContactoLocal
 * @property int $estadoLocal
 * @property string $horarioAtencionLocal
 * @property string $created_at
 * @property string $updated_at
 * @property Ciudade $ciudade
 * @property Comuna $comuna
 * @property CentroProduccione[] $centroProducciones
 * @property Cuenta $cuenta
 * @property LocalPromocion $localPromocion
 * @property LocalesAsociacione $localesAsociacione
 * @property Pago[] $pagos
 * @property Pedido $pedido
 * @property Sectore[] $sectores
 */
class Local extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'idLocal';

    /**
     * @var array
     */
    protected $fillable = ['nombreLocal', 'direccionLocal', 'idComuna', 'idCiudad', 'personaContactoLocal', 'estadoLocal', 'horarioAtencionLocal', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function ciudade()
    {
        return $this->belongsTo('App\Ciudade', 'idCiudad', 'idCiudad');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function comuna()
    {
        return $this->belongsTo('App\Comuna', 'idComuna', 'idComuna');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function centroProducciones()
    {
        return $this->hasMany('App\CentroProduccione', 'idLocal', 'idLocal');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function cuenta()
    {
        return $this->hasOne('App\Cuenta', 'idLocal', 'idLocal');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function localPromocion()
    {
        return $this->hasOne('App\LocalPromocion', 'idLocal', 'idLocal');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function localesAsociacione()
    {
        return $this->hasOne('App\LocalesAsociacione', 'idLocal', 'idLocal');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function pagos()
    {
        return $this->hasMany('App\Pago', 'idLocal', 'idLocal');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function pedido()
    {
        return $this->hasOne('App\Pedido', 'idLocal', 'idLocal');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function sectores()
    {
        return $this->hasMany('App\Sectore', 'idLocal', 'idLocal');
    }
}
