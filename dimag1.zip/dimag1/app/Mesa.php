<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $idMesa
 * @property int $idSector
 * @property int $capacidad
 * @property int $idTipoMesa
 * @property string $created_at
 * @property string $updated_at
 * @property Sectore $sectore
 * @property TipoMesa $tipoMesa
 * @property Cuenta $cuenta
 * @property Pago[] $pagos
 * @property Pedido $pedido
 */
class Mesa extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'idMesa';

    /**
     * @var array
     */
    protected $fillable = ['idSector', 'capacidad', 'idTipoMesa', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function sectore()
    {
        return $this->belongsTo('App\Sectore', 'idSector', 'idSector');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function tipoMesa()
    {
        return $this->belongsTo('App\TipoMesa', 'idTipoMesa', 'idTipoMesa');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function cuenta()
    {
        return $this->hasOne('App\Cuenta', 'idMesa', 'idMesa');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function pagos()
    {
        return $this->hasMany('App\Pago', 'idMesa', 'idMesa');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function pedido()
    {
        return $this->hasOne('App\Pedido', 'idMesa', 'idMesa');
    }
}
