<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $idSector
 * @property string $nombreSector
 * @property int $idLocal
 * @property string $nivelSector
 * @property string $created_at
 * @property string $updated_at
 * @property Local $local
 * @property CentroProduccione[] $centroProducciones
 * @property Cuenta $cuenta
 * @property Mesa $mesa
 * @property Pago[] $pagos
 * @property Pedido $pedido
 */
class Sector extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'sectores';

    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'idSector';

    /**
     * @var array
     */
    protected $fillable = ['nombreSector', 'idLocal', 'nivelSector', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function local()
    {
        return $this->belongsTo('App\Local', 'idLocal', 'idLocal');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function centroProducciones()
    {
        return $this->hasMany('App\CentroProduccione', 'idSector', 'idSector');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function cuenta()
    {
        return $this->hasOne('App\Cuenta', 'idSector', 'idSector');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function mesa()
    {
        return $this->hasOne('App\Mesa', 'idSector', 'idSector');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function pagos()
    {
        return $this->hasMany('App\Pago', 'idSector', 'idSector');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function pedido()
    {
        return $this->hasOne('App\Pedido', 'idSector', 'idSector');
    }
}
