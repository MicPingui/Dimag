<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $idProducto
 * @property string $nombreProducto
 * @property int $idFamilia
 * @property int $idRecetaNegocio
 * @property int $tiempoPreparacionProducto
 * @property boolean $estadoProducto
 * @property string $imagenProducto
 * @property string $observacionesProducto
 * @property int $idTamano
 * @property int $precioComercialProducto
 * @property int $precioCostoProducto
 * @property string $created_at
 * @property string $updated_at
 * @property RecetaNegocio $recetaNegocio
 * @property Familia $familia
 * @property Tamano $tamano
 * @property ProductoPedido $productoPedido
 * @property ProductosAsociacione[] $productosAsociaciones
 * @property ProductosPago $productosPago
 * @property ProductosPromocion $productosPromocion
 */
class Producto extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'idProducto';

    /**
     * @var array
     */
    protected $fillable = ['nombreProducto', 'idFamilia', 'idRecetaNegocio', 'tiempoPreparacionProducto', 'estadoProducto', 'imagenProducto', 'observacionesProducto', 'idTamano', 'precioComercialProducto', 'precioCostoProducto', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function recetaNegocio()
    {
        return $this->belongsTo('App\RecetaNegocio', 'idRecetaNegocio', 'idRecetaNegocio');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function familia()
    {
        return $this->belongsTo('App\Familia', 'idFamilia', 'idFamilia');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function tamano()
    {
        return $this->belongsTo('App\Tamano', 'idTamano', 'idTamano');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function productoPedido()
    {
        return $this->hasOne('App\ProductoPedido', 'idProducto', 'idProducto');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function productosAsociaciones()
    {
        return $this->hasMany('App\ProductosAsociacione', 'idProducto', 'idProducto');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function productosPago()
    {
        return $this->hasOne('App\ProductosPago', 'idProducto', 'idProducto');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function productosPromocion()
    {
        return $this->hasOne('App\ProductosPromocion', 'idProducto', 'idProducto');
    }
}
