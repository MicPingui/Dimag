<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $idCaja
 * @property string $nombreCaja
 * @property string $descripcionCaja
 * @property int $idLocal
 * @property int $idSector
 * @property string $created_at
 * @property string $updated_at
 * @property Cuenta $cuenta
 */
class Caja extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'idCaja';

    /**
     * @var array
     */
    protected $fillable = ['nombreCaja', 'descripcionCaja', 'idLocal', 'idSector', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function cuenta()
    {
        return $this->hasOne('App\Cuenta', 'idCaja', 'idCaja');
    }
}
