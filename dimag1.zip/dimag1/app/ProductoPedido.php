<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $idProductoPedido
 * @property int $idProducto
 * @property int $idPedido
 * @property int $idRecetaCliente
 * @property string $observacionesProductoPedido
 * @property string $created_at
 * @property string $updated_at
 * @property Pedido $pedido
 * @property Producto $producto
 * @property RecetaCliente $recetaCliente
 */
class ProductoPedido extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'idProductoPedido';

    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['idProducto', 'idPedido', 'idRecetaCliente', 'observacionesProductoPedido', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function pedido()
    {
        return $this->belongsTo('App\Pedido', 'idPedido', 'idPedido');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function producto()
    {
        return $this->belongsTo('App\Producto', 'idProducto', 'idProducto');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function recetaCliente()
    {
        return $this->belongsTo('App\RecetaCliente', 'idRecetaCliente', 'idRecetaCliente');
    }
}
