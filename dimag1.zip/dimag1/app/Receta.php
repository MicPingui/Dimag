<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $idRecetaNegocio
 * @property string $nombreRecetaNegocio
 * @property string $created_at
 * @property string $updated_at
 * @property IngredientesRecetaNegocio[] $ingredientesRecetaNegocios
 * @property Producto[] $productos
 */
class Receta extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'receta_negocios';

    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'idRecetaNegocio';

    /**
     * @var array
     */
    protected $fillable = ['nombreRecetaNegocio', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function ingredientesRecetaNegocios()
    {
        return $this->hasMany('App\IngredientesRecetaNegocio', 'idRecetaNegocio', 'idRecetaNegocio');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function productos()
    {
        return $this->hasMany('App\Producto', 'idRecetaNegocio', 'idRecetaNegocio');
    }
}
