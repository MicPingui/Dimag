<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $idIngrediente
 * @property string $nombreIngrediente
 * @property int $idUnidadMedida
 * @property boolean $estadoIngrediente
 * @property string $created_at
 * @property string $updated_at
 * @property UnidadMedida $unidadMedida
 * @property IngredientesRecetaCliente $ingredientesRecetaCliente
 * @property IngredientesRecetaNegocio[] $ingredientesRecetaNegocios
 */
class Ingrediente extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'idIngrediente';

    /**
     * @var array
     */
    protected $fillable = ['nombreIngrediente', 'idUnidadMedida', 'estadoIngrediente', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function unidadMedida()
    {
        return $this->belongsTo('App\UnidadMedida', 'idUnidadMedida', 'idUnidadMedida');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function ingredientesRecetaCliente()
    {
        return $this->hasOne('App\IngredientesRecetaCliente', 'idIngrediente', 'idIngrediente');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function ingredientesRecetaNegocios()
    {
        return $this->hasMany('App\IngredientesRecetaNegocio', 'IdIngrediente', 'idIngrediente');
    }
}
