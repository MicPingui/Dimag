<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $idPedido
 * @property int $tipoPedido
 * @property int $idLocal
 * @property int $idSector
 * @property int $idMesa
 * @property int $idCliente
 * @property int $idUsuario
 * @property string $observacionesPedido
 * @property int $idCentroProduccion
 * @property int $idAsociacion
 * @property int $idEstadoPedido
 * @property int $idEntregaDomicilio
 * @property string $created_at
 * @property string $updated_at
 * @property Asociacione $asociacione
 * @property CentroProduccione $centroProduccione
 * @property Cliente $cliente
 * @property EntregaDomicilio $entregaDomicilio
 * @property EstadoPedido $estadoPedido
 * @property Local $local
 * @property Mesa $mesa
 * @property Sectore $sectore
 * @property User $user
 * @property TipoPedido $tipoPedido
 * @property Cuenta $cuenta
 * @property ProductoPedido $productoPedido
 */
class Pedido extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'idPedido';

    /**
     * @var array
     */
    protected $fillable = ['tipoPedido', 'idLocal', 'idSector', 'idMesa', 'idCliente', 'idUsuario', 'observacionesPedido', 'idCentroProduccion', 'idAsociacion', 'idEstadoPedido', 'idEntregaDomicilio', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function asociacione()
    {
        return $this->belongsTo('App\Asociacione', 'idAsociacion', 'idAsociacion');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function centroProduccione()
    {
        return $this->belongsTo('App\CentroProduccione', 'idCentroProduccion', 'idCentroProduccion');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function cliente()
    {
        return $this->belongsTo('App\Cliente', 'idCliente', 'idCliente');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function entregaDomicilio()
    {
        return $this->belongsTo('App\EntregaDomicilio', 'idEntregaDomicilio', 'idEntregaDomicilio');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function estadoPedido()
    {
        return $this->belongsTo('App\EstadoPedido', 'idEstadoPedido', 'idEstadoPedido');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function local()
    {
        return $this->belongsTo('App\Local', 'idLocal', 'idLocal');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function mesa()
    {
        return $this->belongsTo('App\Mesa', 'idMesa', 'idMesa');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function sectore()
    {
        return $this->belongsTo('App\Sectore', 'idSector', 'idSector');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User', 'idUsuario');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function tipoPedido()
    {
        return $this->belongsTo('App\TipoPedido', 'tipoPedido', 'idTipoPedido');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function cuenta()
    {
        return $this->hasOne('App\Cuenta', 'idPedido', 'idPedido');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function productoPedido()
    {
        return $this->hasOne('App\ProductoPedido', 'idPedido', 'idPedido');
    }
}
