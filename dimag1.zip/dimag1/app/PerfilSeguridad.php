<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $idPerfilSeguridad
 * @property string $nombrePerfilSeguridad
 * @property string $created_at
 * @property string $updated_at
 * @property User[] $users
 */
class PerfilSeguridad extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'seguridad_perfiles';

    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'idPerfilSeguridad';

    /**
     * @var array
     */
    protected $fillable = ['nombrePerfilSeguridad', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function users()
    {
        return $this->hasMany('App\User', 'idPerfilSeguridad', 'idPerfilSeguridad');
    }
}
