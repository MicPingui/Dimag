<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $idRecetaCliente
 * @property string $nombreRecetaCliente
 * @property string $created_at
 * @property string $updated_at
 * @property IngredientesRecetaCliente $ingredientesRecetaCliente
 * @property ProductoPedido $productoPedido
 */
class RecetaCliente extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'idRecetaCliente';

    /**
     * @var array
     */
    protected $fillable = ['nombreRecetaCliente', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function ingredientesRecetaCliente()
    {
        return $this->hasOne('App\IngredientesRecetaCliente', 'idRecetaCliente', 'idRecetaCliente');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function productoPedido()
    {
        return $this->hasOne('App\ProductoPedido', 'idRecetaCliente', 'idRecetaCliente');
    }
}
