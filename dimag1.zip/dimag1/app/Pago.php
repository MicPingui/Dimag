<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $idPago
 * @property int $idLocal
 * @property int $idSector
 * @property int $idMesa
 * @property int $idCuenta
 * @property int $idTipoPago
 * @property string $observacionTipoPago
 * @property int $montoPago
 * @property int $idTipoMoneda
 * @property int $tasaCambioTipoMoneda
 * @property int $idBanco
 * @property int $descuentoPago
 * @property int $recargoPago
 * @property int $montoPropina
 * @property string $created_at
 * @property string $updated_at
 * @property Banco $banco
 * @property Cuenta $cuenta
 * @property Local $local
 * @property Mesa $mesa
 * @property Sectore $sectore
 * @property TipoMoneda $tipoMoneda
 * @property TipoPago $tipoPago
 * @property ProductosPago[] $productosPagos
 */
class Pago extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'idPago';

    /**
     * @var array
     */
    protected $fillable = ['idLocal', 'idSector', 'idMesa', 'idCuenta', 'idTipoPago', 'observacionTipoPago', 'montoPago', 'idTipoMoneda', 'tasaCambioTipoMoneda', 'idBanco', 'descuentoPago', 'recargoPago', 'montoPropina', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function banco()
    {
        return $this->belongsTo('App\Banco', 'idBanco', 'idBanco');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function cuenta()
    {
        return $this->belongsTo('App\Cuenta', 'idCuenta', 'idCuenta');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function local()
    {
        return $this->belongsTo('App\Local', 'idLocal', 'idLocal');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function mesa()
    {
        return $this->belongsTo('App\Mesa', 'idMesa', 'idMesa');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function sectore()
    {
        return $this->belongsTo('App\Sectore', 'idSector', 'idSector');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function tipoMoneda()
    {
        return $this->belongsTo('App\TipoMoneda', 'idTipoMoneda', 'idTipoMoneda');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function tipoPago()
    {
        return $this->belongsTo('App\TipoPago', 'idTipoPago', 'idTipoPago');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function productosPagos()
    {
        return $this->hasMany('App\ProductosPago', 'idPago', 'idPago');
    }
}
