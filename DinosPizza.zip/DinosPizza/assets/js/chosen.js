// CHOSEN
 $(".chosen-select").chosen({no_results_text: "Oops, No se encontro resultado!"});