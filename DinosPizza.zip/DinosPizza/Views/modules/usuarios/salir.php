<?php session_destroy(); ?>
  <div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-3">Sesión finalizada</h1>
    <p class="lead"></p>
  </div>
</div>

<meta http-equiv="refresh" content="3; url=index.php"/>