
 <div class="container" style="background-color: #fff; border-radius: 5px; padding: 7px; margin-top:20px; width: 1140px; margin-left: 8.3%;">

<footer>
	<center>
		<small><i>Copyright (c) Dinos Pizza <?php echo date('Y'); ?> <a href="http://www.magor.cl" target="_blanck"> Magor Spa</a></i></small>
	</center>
</footer>
</div>

	<script src="assets/js/script.js"></script>

<script>
 
$('.mi').on('click',function(){
	$('.su').toggle('slow');
});

$('.mitooltip').tooltip();
  $( function() {
  
  });

</script>
  
 
</body>
</html>