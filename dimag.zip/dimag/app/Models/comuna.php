<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class comuna extends Model
{
    //
    public    $incrementing = false;
    protected $primaryKey = 'idComuna';
}
