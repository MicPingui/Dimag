<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class centro_producciones extends Model
{
    //
}
