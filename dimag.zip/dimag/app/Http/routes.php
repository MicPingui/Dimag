<?php
	Route::resource('locals','LocalController');
?>