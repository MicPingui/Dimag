<?php

namespace App\Http\Controllers;

use App\productosCuenta;
use Illuminate\Http\Request;

class ProductosCuentaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\productosCuenta  $productosCuenta
     * @return \Illuminate\Http\Response
     */
    public function show(productosCuenta $productosCuenta)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\productosCuenta  $productosCuenta
     * @return \Illuminate\Http\Response
     */
    public function edit(productosCuenta $productosCuenta)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\productosCuenta  $productosCuenta
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, productosCuenta $productosCuenta)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\productosCuenta  $productosCuenta
     * @return \Illuminate\Http\Response
     */
    public function destroy(productosCuenta $productosCuenta)
    {
        //
    }
}
