<?php

namespace App\Http\Controllers;

use App\localesAsociaciones;
use Illuminate\Http\Request;

class LocalesAsociacionesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\localesAsociaciones  $localesAsociaciones
     * @return \Illuminate\Http\Response
     */
    public function show(localesAsociaciones $localesAsociaciones)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\localesAsociaciones  $localesAsociaciones
     * @return \Illuminate\Http\Response
     */
    public function edit(localesAsociaciones $localesAsociaciones)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\localesAsociaciones  $localesAsociaciones
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, localesAsociaciones $localesAsociaciones)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\localesAsociaciones  $localesAsociaciones
     * @return \Illuminate\Http\Response
     */
    public function destroy(localesAsociaciones $localesAsociaciones)
    {
        //
    }
}
