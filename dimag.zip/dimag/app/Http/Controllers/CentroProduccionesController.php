<?php

namespace App\Http\Controllers;

use App\centro_producciones;
use Illuminate\Http\Request;

class CentroProduccionesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\centro_producciones  $centro_producciones
     * @return \Illuminate\Http\Response
     */
    public function show(centro_producciones $centro_producciones)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\centro_producciones  $centro_producciones
     * @return \Illuminate\Http\Response
     */
    public function edit(centro_producciones $centro_producciones)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\centro_producciones  $centro_producciones
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, centro_producciones $centro_producciones)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\centro_producciones  $centro_producciones
     * @return \Illuminate\Http\Response
     */
    public function destroy(centro_producciones $centro_producciones)
    {
        //
    }
}
