<?php

namespace App\Http\Controllers;

use App\seguridad_perfiles;
use Illuminate\Http\Request;

class SeguridadPerfilesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\seguridad_perfiles  $seguridad_perfiles
     * @return \Illuminate\Http\Response
     */
    public function show(seguridad_perfiles $seguridad_perfiles)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\seguridad_perfiles  $seguridad_perfiles
     * @return \Illuminate\Http\Response
     */
    public function edit(seguridad_perfiles $seguridad_perfiles)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\seguridad_perfiles  $seguridad_perfiles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, seguridad_perfiles $seguridad_perfiles)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\seguridad_perfiles  $seguridad_perfiles
     * @return \Illuminate\Http\Response
     */
    public function destroy(seguridad_perfiles $seguridad_perfiles)
    {
        //
    }
}
