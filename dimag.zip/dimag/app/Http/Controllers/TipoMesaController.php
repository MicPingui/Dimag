<?php

namespace App\Http\Controllers;

use App\tipoMesa;
use Illuminate\Http\Request;

class TipoMesaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\tipoMesa  $tipoMesa
     * @return \Illuminate\Http\Response
     */
    public function show(tipoMesa $tipoMesa)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\tipoMesa  $tipoMesa
     * @return \Illuminate\Http\Response
     */
    public function edit(tipoMesa $tipoMesa)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\tipoMesa  $tipoMesa
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, tipoMesa $tipoMesa)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\tipoMesa  $tipoMesa
     * @return \Illuminate\Http\Response
     */
    public function destroy(tipoMesa $tipoMesa)
    {
        //
    }
}
