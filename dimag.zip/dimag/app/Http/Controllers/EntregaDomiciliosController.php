<?php

namespace App\Http\Controllers;

use App\entrega_domicilios;
use Illuminate\Http\Request;

class EntregaDomiciliosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\entrega_domicilios  $entrega_domicilios
     * @return \Illuminate\Http\Response
     */
    public function show(entrega_domicilios $entrega_domicilios)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\entrega_domicilios  $entrega_domicilios
     * @return \Illuminate\Http\Response
     */
    public function edit(entrega_domicilios $entrega_domicilios)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\entrega_domicilios  $entrega_domicilios
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, entrega_domicilios $entrega_domicilios)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\entrega_domicilios  $entrega_domicilios
     * @return \Illuminate\Http\Response
     */
    public function destroy(entrega_domicilios $entrega_domicilios)
    {
        //
    }
}
