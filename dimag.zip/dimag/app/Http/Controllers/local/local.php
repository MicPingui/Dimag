<?php
	class local
	{
		var $id;
		var $nombre;
		var $direccion;
		var $idComuna;
		var $idCiudad;
		var $telefono;
		var $personaContacto;
		var $estado;
		var $horarioAtencion;

		function local($nombre, $direccion, $idComuna, $idCiudad, $telefono, $personaContacto, $estado, $horarioAtencion)
		{
			$this->nombre = $nombre;
			$this->direccion = $direccion;
			$this->idComuna = $idComuna;
			$this->idCiudad = $idCiudad;
			$this->personaContacto = $personaContacto;
			$this->estado = $estado;
			$this->horarioAtencion = $horarioAtencion;
		}





	}


?>