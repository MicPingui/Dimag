<?php

namespace App\Http\Controllers;

use App\estadoPedido;
use Illuminate\Http\Request;

class EstadoPedidoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\estadoPedido  $estadoPedido
     * @return \Illuminate\Http\Response
     */
    public function show(estadoPedido $estadoPedido)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\estadoPedido  $estadoPedido
     * @return \Illuminate\Http\Response
     */
    public function edit(estadoPedido $estadoPedido)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\estadoPedido  $estadoPedido
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, estadoPedido $estadoPedido)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\estadoPedido  $estadoPedido
     * @return \Illuminate\Http\Response
     */
    public function destroy(estadoPedido $estadoPedido)
    {
        //
    }
}
