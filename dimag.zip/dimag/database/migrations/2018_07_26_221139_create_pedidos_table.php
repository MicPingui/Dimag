<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePedidosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pedidos', function (Blueprint $table) {
            $table->increments('idPedido')->unsigned();
            $table->integer('tipoPedido')->unique()->unsigned();
            $table->foreign('tipoPedido')->references('idTipoPedido')->on('tipo_pedidos');
            $table->integer('idLocal')->unique()->unsigned();
            $table->foreign('idLocal')->references('idLocal')->on('locals');
            $table->integer('idSector')->unique()->unsigned();
            $table->foreign('idSector')->references('idSector')->on('sectores');
            $table->integer('idMesa')->unique()->unsigned();
            $table->foreign('idMesa')->references('idMesa')->on('mesas');
            $table->integer('idCliente')->unique()->unsigned();
            $table->foreign('idCliente')->references('idCliente')->on('clientes');
            $table->integer('idUsuario')->unique()->unsigned();
            $table->foreign('idUsuario')->references('id')->on('users');
            $table->string('observacionesPedido');
            $table->integer('idCentroProduccion')->unique()->unsigned();
            $table->foreign('idCentroProduccion')->references('idCentroProduccion')->on('centro_producciones');
            $table->integer('idAsociacion')->unique()->unsigned();
            $table->foreign('idAsociacion')->references('idAsociacion')->on('asociaciones');
            $table->integer('idEstadoPedido')->unique()->unsigned();
            $table->foreign('idEstadoPedido')->references('idEstadoPedido')->on('estado_pedidos');
            $table->integer('idEntregaDomicilio')->unique()->unsigned();
            $table->foreign('idEntregaDomicilio')->references('idEntregaDomicilio')->on('entrega_domicilios');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pedidos');
    }
}
