<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCuentasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cuentas', function (Blueprint $table) {
            $table->increments('idCuenta')->unsigned();
            $table->integer('idLocal')->unique()->unsigned();
            $table->foreign('idLocal')->references('idLocal')->on('locals');
            $table->integer('idSector')->unique()->unsigned();
            $table->foreign('idSector')->references('idSector')->on('sectores');
            $table->integer('idMesa')->unique()->unsigned();
            $table->foreign('idMesa')->references('idMesa')->on('mesas');
            $table->integer('idCliente')->unique()->unsigned();
            $table->foreign('idCliente')->references('idCliente')->on('clientes');
            $table->integer('idPedido')->unique()->unsigned();
            $table->foreign('idPedido')->references('idPedido')->on('pedidos');
            $table->integer('idCaja')->unique()->unsigned();
            $table->foreign('idCaja')->references('idCaja')->on('cajas');
            $table->boolean('propina');
            $table->integer('montoPropina')->unsigned();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cuentas');
    }
}
