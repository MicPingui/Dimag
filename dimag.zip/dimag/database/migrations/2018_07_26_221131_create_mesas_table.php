<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMesasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('mesas', function (Blueprint $table) {
            $table->increments('idMesa')->unsigned();
            $table->integer('idSector')->unique()->unsigned();
            $table->foreign('idSector')->references('idSector')->on('sectores');
            $table->integer('capacidad');
            $table->integer('idTipoMesa')->unique()->unsigned();
            $table->foreign('idTipoMesa')->references('idTipoMesa')->on('tipo_mesas');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mesas');
    }
}
