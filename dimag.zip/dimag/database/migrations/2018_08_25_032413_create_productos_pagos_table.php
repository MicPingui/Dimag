<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductosPagosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('productos_pagos', function (Blueprint $table) {
            $table->increments('idProductoPagos')->unsigned();
            $table->integer('idProducto')->unique()->unsigned();
            $table->foreign('idProducto')->references('idProducto')->on('productos');
            $table->integer('idPago')->unsigned();
            $table->foreign('idPago')->references('idPago')->on('pagos');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('productos_pagos');
    }
}
