<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLocalesAsociacionesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('locales_asociaciones', function (Blueprint $table) {
            $table->increments('idLocalAsociacion')->unsigned();
            $table->integer('idLocal')->unique()->unsigned();
            $table->foreign('idLocal')->references('idLocal')->on('locals');
            $table->integer('idAsociacion')->unique()->unsigned();
            $table->foreign('idAsociacion')->references('idAsociacion')->on('asociaciones');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('locales_asociaciones');
    }
}
