<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateIngredientesRecetaClientesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ingredientes_receta_clientes', function (Blueprint $table) {
            $table->increments('idIngredienteReceta')->unsigned();
            $table->integer('idIngrediente')->unique()->unsigned();
            $table->foreign('idIngrediente')->references('idIngrediente')->on('ingredientes');
            $table->integer('idRecetaCliente')->unique()->unsigned();
            $table->foreign('idRecetaCliente')->references('idRecetaCliente')->on('receta_clientes');
            $table->integer('cantidadIngrediente')->unsigned();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ingredientes_receta_clientes');
    }
}
