<?php

use Faker\Generator as Faker;

$factory->define(App\productosPromocion::class, function (Faker $faker) {
    return [
        //
    ];
});
