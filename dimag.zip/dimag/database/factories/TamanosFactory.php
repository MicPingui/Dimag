<?php

use Faker\Generator as Faker;

$factory->define(App\tamanos::class, function (Faker $faker) {
    return [
        //
    ];
});
