<?php

use Faker\Generator as Faker;

$factory->define(App\recetaCliente::class, function (Faker $faker) {
    return [
        //
    ];
});
