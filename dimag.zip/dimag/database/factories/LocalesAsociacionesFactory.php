<?php

use Faker\Generator as Faker;

$factory->define(App\localesAsociaciones::class, function (Faker $faker) {
    return [
        //
    ];
});
