<?php

use Faker\Generator as Faker;

$factory->define(App\sectores::class, function (Faker $faker) {
    return [
        //
    ];
});
