<?php

use Faker\Generator as Faker;

$factory->define(App\centro_producciones::class, function (Faker $faker) {
    return [
        //
    ];
});
