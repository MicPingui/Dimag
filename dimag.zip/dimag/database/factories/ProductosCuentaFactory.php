<?php

use Faker\Generator as Faker;

$factory->define(App\productosCuenta::class, function (Faker $faker) {
    return [
        //
    ];
});
