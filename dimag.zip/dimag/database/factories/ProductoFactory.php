<?php

use Faker\Generator as Faker;

$factory->define(App\producto::class, function (Faker $faker) {
    return [
        //
    ];
});
