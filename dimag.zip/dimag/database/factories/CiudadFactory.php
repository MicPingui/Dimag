<?php

use Faker\Generator as Faker;

$factory->define(App\ciudad::class, function (Faker $faker) {
    return [
        //
    ];
});
