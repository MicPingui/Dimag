<?php

use Faker\Generator as Faker;

$factory->define(App\genero::class, function (Faker $faker) {
    return [
        //
    ];
});
