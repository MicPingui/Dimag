<?php

use Faker\Generator as Faker;

$factory->define(App\productos_pagos::class, function (Faker $faker) {
    return [
        //
    ];
});
