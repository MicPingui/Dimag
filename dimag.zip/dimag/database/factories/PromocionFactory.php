<?php

use Faker\Generator as Faker;

$factory->define(App\promocion::class, function (Faker $faker) {
    return [
        //
    ];
});
