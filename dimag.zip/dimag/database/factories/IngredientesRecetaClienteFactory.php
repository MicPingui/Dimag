<?php

use Faker\Generator as Faker;

$factory->define(App\ingredientesRecetaCliente::class, function (Faker $faker) {
    return [
        //
    ];
});
