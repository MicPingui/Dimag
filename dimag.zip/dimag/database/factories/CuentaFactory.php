<?php

use Faker\Generator as Faker;

$factory->define(App\cuenta::class, function (Faker $faker) {
    return [
        //
    ];
});
