<?php

use Faker\Generator as Faker;

$factory->define(App\tamaños::class, function (Faker $faker) {
    return [
        //
    ];
});
