<?php

use Faker\Generator as Faker;

$factory->define(App\local::class, function (Faker $faker) {
    return [
        //
    ];
});
