<?php

use Faker\Generator as Faker;

$factory->define(App\comuna::class, function (Faker $faker) {
    return [
        //
    ];
});
