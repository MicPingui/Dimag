<?php

use Faker\Generator as Faker;

$factory->define(App\ciudades::class, function (Faker $faker) {
    return [
        //
    ];
});
