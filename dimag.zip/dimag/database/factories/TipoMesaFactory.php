<?php

use Faker\Generator as Faker;

$factory->define(App\tipoMesa::class, function (Faker $faker) {
    return [
        //
    ];
});
