<?php

use Faker\Generator as Faker;

$factory->define(App\localPromocion::class, function (Faker $faker) {
    return [
        //
    ];
});
