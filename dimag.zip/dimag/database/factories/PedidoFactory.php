<?php

use Faker\Generator as Faker;

$factory->define(App\pedido::class, function (Faker $faker) {
    return [
        //
    ];
});
