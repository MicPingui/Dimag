<?php

use Faker\Generator as Faker;

$factory->define(App\entrega_domicilios::class, function (Faker $faker) {
    return [
        //
    ];
});
