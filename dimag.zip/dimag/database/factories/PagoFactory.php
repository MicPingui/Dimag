<?php

use Faker\Generator as Faker;

$factory->define(App\pago::class, function (Faker $faker) {
    return [
        //
    ];
});
