<?php

use Faker\Generator as Faker;

$factory->define(App\productosAsociaciones::class, function (Faker $faker) {
    return [
        //
    ];
});
