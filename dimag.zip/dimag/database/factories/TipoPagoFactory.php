<?php

use Faker\Generator as Faker;

$factory->define(App\tipoPago::class, function (Faker $faker) {
    return [
        //
    ];
});
