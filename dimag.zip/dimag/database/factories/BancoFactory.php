<?php

use Faker\Generator as Faker;

$factory->define(App\banco::class, function (Faker $faker) {
    return [
        //
    ];
});
