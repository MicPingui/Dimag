<?php

use Faker\Generator as Faker;

$factory->define(App\seguridad_perfiles::class, function (Faker $faker) {
    return [
        //
    ];
});
