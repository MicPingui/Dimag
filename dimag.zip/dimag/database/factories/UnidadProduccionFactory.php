<?php

use Faker\Generator as Faker;

$factory->define(App\unidadProduccion::class, function (Faker $faker) {
    return [
        //
    ];
});
