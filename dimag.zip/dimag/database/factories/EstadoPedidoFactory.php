<?php

use Faker\Generator as Faker;

$factory->define(App\estadoPedido::class, function (Faker $faker) {
    return [
        //
    ];
});
